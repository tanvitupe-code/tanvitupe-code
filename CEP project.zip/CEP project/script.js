
        // --- STATE & CONFIG ---
        const API_URL = 'http://localhost:5000/api';
        let currentUser = JSON.parse(localStorage.getItem('user')) || null;
        let token = localStorage.getItem('token') || null;
        let useMockBackend = false; 
        
        // Data State for Filtering
        let allFetchedIssues = [];

        // Audio Recording State
        let mediaRecorder;
        let audioChunks = [];
        let recordedAudioBlob = null;

        // --- CORE UI FUNCTIONS ---
        function switchView(viewId) {
            document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
            document.getElementById(viewId).classList.add('active');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        function showToast(message, type = 'success') {
            const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
            const toastHtml = `
                <div class="toast align-items-center text-white bg-${type} border-0 shadow-lg show mb-2" role="alert" aria-live="assertive" aria-atomic="true" style="border-radius: 10px;">
                    <div class="d-flex p-1">
                        <div class="toast-body fw-medium"><i class="fas ${icon} me-2"></i> ${message}</div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" onclick="this.parentElement.parentElement.remove()"></button>
                    </div>
                </div>`;
            document.getElementById('toastContainer').insertAdjacentHTML('beforeend', toastHtml);
            setTimeout(() => {
                const toast = document.getElementById('toastContainer').firstElementChild;
                if (toast) toast.remove();
            }, 3500);
        }

        function updateNav() {
            if (currentUser) {
                const initial = currentUser.name.charAt(0).toUpperCase();
                document.getElementById('userNameDisplay').innerHTML = `
                    <div style="width:30px; height:30px; border-radius:50%; background:#e2e8f0; color:var(--primary-color); display:flex; align-items:center; justify-content:center; font-weight:bold;">${initial}</div>
                    <div>
                        <div class="lh-1 text-dark">${currentUser.name}</div>
                        <small class="lh-1 text-muted" style="font-size:0.7rem; text-transform:uppercase;">${currentUser.role}</small>
                    </div>`;
                document.getElementById('btnLogout').classList.remove('d-none');
            } else {
                document.getElementById('userNameDisplay').innerHTML = '';
                document.getElementById('btnLogout').classList.add('d-none');
            }
        }

        // --- HELPER: TIME AGO ---
        function timeAgo(dateString) {
            const date = new Date(dateString);
            const now = new Date();
            const seconds = Math.round((now - date) / 1000);
            const minutes = Math.round(seconds / 60);
            const hours = Math.round(minutes / 60);
            const days = Math.round(hours / 24);

            if (seconds < 60) return 'Just now';
            if (minutes < 60) return `${minutes}m ago`;
            if (hours < 24) return `${hours}h ago`;
            if (days < 7) return `${days}d ago`;
            return date.toLocaleDateString();
        }

        // --- API WRAPPER WITH MOCK FALLBACK ---
        async function apiCall(endpoint, method = 'GET', body = null, isFormData = false) {
            const headers = {};
            if (token) headers['Authorization'] = `Bearer ${token}`;
            if (!isFormData && body) headers['Content-Type'] = 'application/json';

            const options = { method, headers };
            if (body) options.body = isFormData ? body : JSON.stringify(body);

            try {
                if(useMockBackend) throw new Error("Force Mock");
                const response = await fetch(API_URL + endpoint, options);
                const data = await response.json();
                if (!response.ok) throw new Error(data.message || 'API Error');
                return data;
            } catch (error) {
                if(!useMockBackend) {
                    console.warn("Server unreachable. Enabling Mock Backend.");
                    document.getElementById('mockBanner').style.display = 'block';
                    useMockBackend = true;
                }
                return executeMockApi(endpoint, method, body, isFormData);
            }
        }

        // --- AUTHENTICATION ---
        document.getElementById('registerForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = e.target.querySelector('button');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            btn.disabled = true;

            const payload = {
                name: document.getElementById('regName').value,
                email: document.getElementById('regEmail').value,
                password: document.getElementById('regPassword').value,
                role: document.getElementById('regRole').value
            };
            try {
                await apiCall('/auth/register', 'POST', payload);
                showToast('Registration successful! Please login.');
                switchView('view-login');
                e.target.reset();
            } catch (err) { showToast(err.message, 'danger'); }
            finally { btn.innerHTML = 'Register Account'; btn.disabled = false; }
        });

        document.getElementById('loginForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = e.target.querySelector('button');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Authenticating...';
            btn.disabled = true;

            const payload = {
                email: document.getElementById('loginEmail').value,
                password: document.getElementById('loginPassword').value
            };
            try {
                const res = await apiCall('/auth/login', 'POST', payload);
                token = res.token;
                currentUser = res.user;
                localStorage.setItem('token', token);
                localStorage.setItem('user', JSON.stringify(currentUser));
                showToast(`Welcome back, ${currentUser.name}!`);
                initDashboard();
                e.target.reset();
            } catch (err) { showToast(err.message, 'danger'); }
            finally { btn.innerHTML = 'Sign In'; btn.disabled = false; }
        });

        document.getElementById('btnLogout').addEventListener('click', () => {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            token = null;
            currentUser = null;
            updateNav();
            switchView('view-login');
        });

        function initDashboard() {
            updateNav();
            if (!currentUser) { switchView('view-login'); return; }
            if (currentUser.role === 'Civic') {
                switchView('view-civic');
                loadCivicIssues();
            } else {
                switchView('view-admin');
                loadAdminIssues();
            }
        }

        // --- CIVIC FEATURES ---
        
        // Geolocation
        document.getElementById('btnLocation').addEventListener('click', () => {
            const btn = document.getElementById('btnLocation');
            if (navigator.geolocation) {
                btn.innerHTML = '<i class="fas fa-spinner fa-spin text-primary me-2"></i> Locating...';
                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        document.getElementById('cLat').value = position.coords.latitude;
                        document.getElementById('cLng').value = position.coords.longitude;
                        document.getElementById('locationDisplay').innerHTML = `<i class="fas fa-check-circle me-1"></i> GPS: ${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`;
                        document.getElementById('locationDisplay').classList.remove('d-none');
                        btn.innerHTML = '<i class="fas fa-map-marker-alt text-success me-2"></i> Location Attached';
                    },
                    (error) => { showToast('Unable to retrieve location.', 'danger'); btn.innerHTML = '<i class="fas fa-map-marker-alt text-danger me-2"></i> Attach Exact GPS Coordinates'; }
                );
            } else { showToast('Geolocation not supported.', 'danger'); }
        });

        // Audio Recording
        document.getElementById('btnRecordAudio').addEventListener('click', async () => {
            const btn = document.getElementById('btnRecordAudio');
            const player = document.getElementById('audioPlayback');

            if (mediaRecorder && mediaRecorder.state === 'recording') {
                mediaRecorder.stop();
                btn.innerHTML = '<i class="fas fa-microphone text-primary me-2"></i> Re-record Audio';
            } else {
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    mediaRecorder = new MediaRecorder(stream);
                    mediaRecorder.start();
                    audioChunks = [];
                    
                    mediaRecorder.addEventListener("dataavailable", event => { audioChunks.push(event.data); });
                    mediaRecorder.addEventListener("stop", () => {
                        recordedAudioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                        player.src = URL.createObjectURL(recordedAudioBlob);
                        player.classList.remove('d-none');
                    });

                    btn.innerHTML = '<i class="fas fa-stop-circle text-danger me-2"></i> Stop Recording';
                } catch (err) { showToast('Microphone access denied.', 'danger'); }
            }
        });

        // Submit Complaint
        document.getElementById('complaintForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = e.target.querySelector('button[type="submit"]');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Uploading...';
            btn.disabled = true;

            const formData = new FormData();
            formData.append('title', document.getElementById('cTitle').value);
            formData.append('category', document.getElementById('cCategory').value); // New Field
            formData.append('area', document.getElementById('cArea').value);         // New Field
            formData.append('description', document.getElementById('cDesc').value);
            formData.append('priority', document.getElementById('cPriority').value); 
            formData.append('image', document.getElementById('cImage').files[0]);
            
            if (document.getElementById('cLat').value) {
                formData.append('latitude', document.getElementById('cLat').value);
                formData.append('longitude', document.getElementById('cLng').value);
            }
            if (recordedAudioBlob) {
                formData.append('audio', recordedAudioBlob, 'recording.webm');
            }

            try {
                await apiCall('/complaints', 'POST', formData, true);
                showToast('Report submitted successfully!');
                e.target.reset();
                document.getElementById('locationDisplay').classList.add('d-none');
                document.getElementById('audioPlayback').classList.add('d-none');
                document.getElementById('btnLocation').innerHTML = '<i class="fas fa-map-marker-alt text-danger me-2"></i> Attach Exact GPS Coordinates';
                document.getElementById('btnRecordAudio').innerHTML = '<i class="fas fa-microphone text-primary me-2"></i> Add Voice Note';
                recordedAudioBlob = null;
                
                document.getElementById('c-all').checked = true;
                document.getElementById('civicSearch').value = '';
                loadCivicIssues();
            } catch (err) { showToast(err.message, 'danger'); }
            finally { btn.innerHTML = '<i class="fas fa-paper-plane me-2"></i> Submit Report'; btn.disabled = false; }
        });

        // Filter Logic Setup
        document.querySelectorAll('input[name="civicFilter"]').forEach(el => el.addEventListener('change', renderCivicIssues));
        document.getElementById('civicSearch').addEventListener('input', renderCivicIssues);
        
        document.querySelectorAll('input[name="adminFilter"]').forEach(el => el.addEventListener('change', renderAdminIssues));
        document.getElementById('adminSort').addEventListener('change', renderAdminIssues); // Event for new sorting dropdown
        document.getElementById('adminSearch').addEventListener('input', renderAdminIssues);


        async function loadCivicIssues() {
            try {
                allFetchedIssues = await apiCall('/complaints/my-issues');
                renderCivicIssues();
            } catch (err) { showToast('Failed to load issues', 'danger'); }
        }

        function renderCivicIssues() {
            const filter = document.querySelector('input[name="civicFilter"]:checked').value;
            const searchTerm = document.getElementById('civicSearch').value.toLowerCase();
            const container = document.getElementById('civicIssuesList');
            
            let filtered = [...allFetchedIssues];
            
            if (filter !== 'All') {
                filtered = filtered.filter(i => i.status === filter);
            }
            if (searchTerm) {
                filtered = filtered.filter(i => i.title.toLowerCase().includes(searchTerm) || i.description.toLowerCase().includes(searchTerm));
            }

            container.innerHTML = filtered.length === 0 ? 
                '<div class="col-12 text-center py-5 text-muted"><i class="fas fa-folder-open fa-3x mb-3 opacity-25"></i><h5>No reports found</h5></div>' : '';
            
            filtered.forEach(issue => {
                container.innerHTML += `<div class="col-12">${createIssueCard(issue, false)}</div>`;
            });
        }


        // --- ADMIN FEATURES ---
        async function loadAdminIssues() {
            try {
                allFetchedIssues = await apiCall('/complaints/all');
                
                // Update Statistics
                const total = allFetchedIssues.length;
                const resolved = allFetchedIssues.filter(i => i.status === 'Resolved').length;
                const pending = total - resolved;

                document.getElementById('statTotal').innerText = total;
                document.getElementById('statPending').innerText = pending;
                document.getElementById('statResolved').innerText = resolved;
                
                renderAdminIssues();
            } catch (err) { showToast('Failed to load dashboard data', 'danger'); }
        }

        function renderAdminIssues() {
            const filter = document.querySelector('input[name="adminFilter"]:checked').value;
            const sortMethod = document.getElementById('adminSort').value;
            const searchTerm = document.getElementById('adminSearch').value.toLowerCase();
            const container = document.getElementById('adminIssuesList');
            
            let filtered = [...allFetchedIssues]; // Shallow copy to allow sorting safely
            
            // 1. Apply Filtering
            if (filter === 'HighPriority') {
                filtered = filtered.filter(i => i.priority === 'High' && i.status !== 'Resolved');
            } else if (filter !== 'All') {
                filtered = filtered.filter(i => i.status === filter);
            }
            
            // 2. Apply Searching
            if (searchTerm) {
                filtered = filtered.filter(i => 
                    i.title.toLowerCase().includes(searchTerm) || 
                    i.description.toLowerCase().includes(searchTerm) ||
                    (i.category && i.category.toLowerCase().includes(searchTerm)) ||
                    (i.area && i.area.toLowerCase().includes(searchTerm)) ||
                    (i.civicId && i.civicId.name.toLowerCase().includes(searchTerm))
                );
            }

            // 3. Apply Sorting & Grouping Logic
            if (sortMethod === 'date') {
                filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
            } 
            else if (sortMethod === 'category') {
                filtered.sort((a, b) => (a.category || 'Z').localeCompare(b.category || 'Z'));
            } 
            else if (sortMethod === 'location') {
                filtered.sort((a, b) => (a.area || 'Z').localeCompare(b.area || 'Z'));
            } 
            else if (sortMethod === 'category_location') {
                // Group by Category first, then sort by Area inside that category
                filtered.sort((a, b) => {
                    const catA = a.category || 'Z';
                    const catB = b.category || 'Z';
                    if (catA !== catB) return catA.localeCompare(catB);
                    
                    const areaA = a.area || 'Z';
                    const areaB = b.area || 'Z';
                    return areaA.localeCompare(areaB);
                });
            }

            // 4. Render
            container.innerHTML = filtered.length === 0 ? 
                '<div class="col-12 text-center py-5 text-muted"><i class="fas fa-check-double fa-3x mb-3 opacity-25"></i><h5>Inbox Zero! No matching reports.</h5></div>' : '';
            
            filtered.forEach(issue => {
                container.innerHTML += `<div class="col-md-6">${createIssueCard(issue, true)}</div>`;
            });
        }

        function openReplyModal(id, currentStatus, currentReply) {
            document.getElementById('modalIssueId').value = id;
            document.getElementById('modalReplyText').value = currentReply || '';
            document.getElementById('modalResolveCheck').checked = currentStatus === 'Resolved';
            new bootstrap.Modal(document.getElementById('replyModal')).show();
        }

        async function submitAdminReply() {
            const btn = document.querySelector('#replyModal .btn-primary');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            btn.disabled = true;

            const id = document.getElementById('modalIssueId').value;
            const reply = document.getElementById('modalReplyText').value;
            const resolve = document.getElementById('modalResolveCheck').checked;

            try {
                await apiCall(`/complaints/${id}/reply`, 'PUT', { 
                    adminReply: reply, 
                    status: resolve ? 'Resolved' : 'Pending' 
                });
                bootstrap.Modal.getInstance(document.getElementById('replyModal')).hide();
                showToast('Issue updated successfully!');
                loadAdminIssues(); 
            } catch (err) { showToast(err.message, 'danger'); }
            finally { btn.innerHTML = 'Save Update'; btn.disabled = false; }
        }

        // --- UI HELPERS ---
        function createIssueCard(issue, isAdminView) {
            const isResolved = issue.status === 'Resolved';
            const statusBadge = isResolved ? 
                '<span class="badge status-badge badge-resolved"><i class="fas fa-check-circle me-1"></i> Resolved</span>' : 
                '<span class="badge status-badge badge-pending"><i class="fas fa-clock me-1"></i> Pending</span>';
            
            let priorityBadge = '';
            const prio = issue.priority || 'Medium'; 
            if(prio === 'High') priorityBadge = '<span class="badge bg-danger priority-badge"><i class="fas fa-fire"></i> High</span>';
            else if(prio === 'Medium') priorityBadge = '<span class="badge bg-warning text-dark priority-badge">Med</span>';
            else priorityBadge = '<span class="badge bg-secondary priority-badge">Low</span>';

            // New Tags for Grouping
            const categoryBadge = issue.category ? `<span class="badge bg-info text-dark priority-badge" style="background-color: #e0f2fe !important; color: #0284c7 !important; border: 1px solid #bae6fd;"><i class="fas fa-tag"></i> ${issue.category}</span>` : '';
            const areaBadge = issue.area ? `<span class="badge bg-light text-dark border priority-badge"><i class="fas fa-map"></i> ${issue.area}</span>` : '';

            const imgUrl = useMockBackend ? issue.image : (issue.image ? `${API_URL.replace('/api','')}/${issue.image}` : '');
            const audioUrl = useMockBackend ? issue.audio : (issue.audio ? `${API_URL.replace('/api','')}/${issue.audio}` : null);
            const dateStr = issue.createdAt ? timeAgo(issue.createdAt) : 'Recently';

            let html = `
                <div class="card issue-card h-100 p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <div class="d-flex flex-wrap gap-1 mb-2 align-items-center">
                                ${statusBadge} ${priorityBadge} ${categoryBadge} ${areaBadge}
                            </div>
                            <h5 class="fw-bold text-dark mb-1 lh-sm">${issue.title}</h5>
                            <small class="text-muted"><i class="fas fa-calendar-alt me-1"></i> ${dateStr}</small>
                        </div>
                    </div>
                    
                    <p class="text-muted small mb-3 flex-grow-1">${issue.description}</p>
            `;

            if (imgUrl) html += `<div class="mb-3"><img src="${imgUrl}" class="img-preview" alt="Issue Image" loading="lazy"></div>`;
            if (audioUrl) html += `<div class="mb-3"><audio controls src="${audioUrl}" class="audio-player"></audio></div>`;
            
            if (issue.location && issue.location.lat) {
                html += `<div class="p-2 bg-light rounded small text-secondary mb-3 border d-inline-block">
                            <i class="fas fa-map-marker-alt text-danger me-1"></i> 
                            GPS: ${Number(issue.location.lat).toFixed(4)}, ${Number(issue.location.lng).toFixed(4)}
                         </div>`;
            }

            if (issue.adminReply) {
                const replyClass = isResolved ? 'alert-success border-success' : 'alert-info border-info';
                html += `<div class="alert ${replyClass} border py-2 px-3 mt-auto mb-3" style="border-radius:10px;">
                            <div class="small fw-bold text-dark mb-1"><i class="fas fa-shield-alt text-primary me-1"></i> Official Response:</div>
                            <small class="text-dark opacity-75">${issue.adminReply}</small>
                         </div>`;
            } else {
                html += `<div class="mt-auto mb-3"></div>`; // spacer
            }

            if (isAdminView) {
                const reporterName = issue.civicId ? issue.civicId.name : 'Unknown Citizen';
                const escReply = (issue.adminReply || '').replace(/'/g, "\\'");
                html += `<hr class="text-muted mt-0">
                         <div class="d-flex justify-content-between align-items-center">
                            <div class="small text-muted fw-medium"><i class="fas fa-user-circle me-1"></i> ${reporterName}</div>
                            <button class="btn btn-sm ${isResolved ? 'btn-light border text-muted' : 'btn-primary'} fw-bold" 
                                onclick="openReplyModal('${issue._id}', '${issue.status}', '${escReply}')">
                                ${isResolved ? '<i class="fas fa-edit"></i> Edit' : '<i class="fas fa-reply"></i> Resolve'}
                            </button>
                         </div>`;
            }

            html += `</div>`;
            return html;
        }

        // --- MOCK BACKEND ENGINE ---
        async function executeMockApi(endpoint, method, body, isFormData) {
            await new Promise(r => setTimeout(r, 600)); // Simulating realistic network delay
            
            let users = JSON.parse(localStorage.getItem('mock_users') || '[]');
            let complaints = JSON.parse(localStorage.getItem('mock_complaints') || '[]');

            if (endpoint === '/auth/register' && method === 'POST') {
                if (users.find(u => u.email === body.email)) throw new Error('Email already registered.');
                const newUser = { _id: Date.now().toString(), ...body };
                users.push(newUser);
                localStorage.setItem('mock_users', JSON.stringify(users));
                return { message: 'Registered' };
            }

            if (endpoint === '/auth/login' && method === 'POST') {
                const user = users.find(u => u.email === body.email && u.password === body.password);
                if (!user) throw new Error('Incorrect email or password.');
                return { token: `mock_token_${user._id}`, user: { id: user._id, name: user.name, role: user.role } };
            }

            if (endpoint === '/complaints' && method === 'POST') {
                const toBase64 = file => new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.readAsDataURL(file);
                    reader.onload = () => resolve(reader.result);
                    reader.onerror = error => reject(error);
                });

                const newIssue = {
                    _id: Date.now().toString(),
                    title: body.get('title'),
                    category: body.get('category') || 'Other', // Saved Category
                    area: body.get('area') || 'Unknown',       // Saved Area
                    description: body.get('description'),
                    priority: body.get('priority') || 'Medium',
                    status: 'Pending',
                    adminReply: '',
                    civicId: currentUser,
                    location: body.get('latitude') ? { lat: body.get('latitude'), lng: body.get('longitude') } : null,
                    image: body.get('image') ? await toBase64(body.get('image')) : null,
                    audio: body.get('audio') ? await toBase64(body.get('audio')) : null,
                    createdAt: new Date().toISOString()
                };

                complaints.push(newIssue);
                localStorage.setItem('mock_complaints', JSON.stringify(complaints));
                return { message: 'Created' };
            }

            if (endpoint === '/complaints/my-issues' && method === 'GET') {
                return complaints.filter(c => c.civicId.id === currentUser.id).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
            }

            if (endpoint === '/complaints/all' && method === 'GET') {
                return complaints.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
            }

            if (endpoint.includes('/reply') && method === 'PUT') {
                const id = endpoint.split('/')[2];
                const index = complaints.findIndex(c => c._id === id);
                if (index > -1) {
                    complaints[index].adminReply = body.adminReply;
                    complaints[index].status = body.status;
                    localStorage.setItem('mock_complaints', JSON.stringify(complaints));
                    return { message: 'Updated' };
                }
            }
            throw new Error("Mock API Route Not Found");
        }

        // Initialize App
        initDashboard();

